const Router =require ( "express")
const movie =require ( "../controllers/movie")
const router = new Router();

router.post('/movie',movie.create)
router.get('/movie', movie.findAll)
router.get('/movie/:id', movie.findOne)
router.put('/movie', movie.update)
router.delete('/movie/:id', movie.delete)

module.exports = router