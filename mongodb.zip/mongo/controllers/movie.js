const movie =require ( "../models/movie")
exports.create = async (req, res) => {
    try {
        const {author, title, content, yearOfPublish, ranking} = req.body
        const movie = await movie.create({author, title, content, yearOfPublish, ranking})
        res.json(movie)
    } catch (e) {
        res.status(500).json(e)
    }


    await movie.save().then(data => {
        res.send({
            message:"Movie was added",
            movie:data
        });
    }).catch(err => {
        res.status(500).send({
            message: err.message || "ERROR"
        });
    })
};

exports.findAll = async (req, res) => {
    try {
        const movie = await movie.find();
        res.status(200).json(movie);
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};

exports.findOne = async (req, res) => {
    try {
        const movie = await movie.findById(req.params.id);
        res.status(200).json(movie);
        if(!req.id) {
            res.status(400).send({
                message: "Movie is not exist!"
            })
        }
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};

exports.update = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }

    const id = req.params.id;

    await movie.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `User not found.`
            });
        }else{
            res.send({ message: "User updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};

exports.delete = async (req, res) => {
    await movie.findByIdAndRemove(req.params.id).then(data => {
        if (!data) {
            res.status(404).send({
                message: `Movie not found.`
            });
        } else {
            res.send({
                message: "Movie deleted successfully!"
            });
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};


