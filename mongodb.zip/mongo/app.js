const express =require ('express')
const mongoose =require ( 'mongoose')
const router =require ( "./router/router")
const PORT = 3000;
const DB_URl = 'mongodb+srv://Dias:Dias12345@cluster0.2mqd1.mongodb.net/?retryWrites=true&w=majority'
const app = express();
app.use(express.json())
app.use('/api' , router)
app.use('/movie' , router)

async function start(){
    try {
        app.listen(PORT, ()=>console.log("STARTED"))
        await mongoose.connect(DB_URl, {useUnifiedTopology: true, useNewUrlParser:true})
        //app.listen(PORT, ()=>console.log("STARTED"))
    }catch (e){
        console.log(e)
    }
}

start()


app.get('/',(req,res)=>{
    res.status(200).json('Сервер работает')
})
