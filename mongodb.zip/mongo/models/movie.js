const mongoose = require('mongoose');
const Schema = mongoose.Schema

const movieSchema = new Schema({
    author:{
        type:String,
        required: true
    },
    title: {
        type: String,
        require: true,
        min: 7,
        max: 15,
    },
    content: {
      type:String,
      require:true 
    },
    yearOfPublish:{
        type: Number,
        require: true,
        min: 8
    },
    ranking:{
        type: Number,
        require: true,
        max: 10
    }
})

//export default mongoose.model('movie',movie)
let movie = new mongoose.model('movie',movieSchema)
module.exports=movie