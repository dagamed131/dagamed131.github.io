const mongoose = require('mongoose');
const Schema = mongoose.Schema

const clientSchema = new Schema({
    username: {
        type: String,
        require: true,
        min: 7,
        max: 15,
    },
    password:{
        type: String,
        require: true,
        min: 8
    }
})