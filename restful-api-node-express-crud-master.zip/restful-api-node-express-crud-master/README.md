# restful-api-node-express-crud
simple project with node and express to create restful api's (CRUD)

# How to start Project 

 npm install 
 
 npm run start 
 
 open browser and run below url
 
 http://localhost:8000/

# server.js 
is used to handle all routes 

## user.js 
file is used for now as dummy database and helper file 
we will modify the project one by one step.

Happy learning :) 

This is just a simple project to start with simple concept of javascript and you can modify the server.js with ES6 code .
Try ES6 code to modify the server.js to learn .
How to start is more imoortant .
I hope it will help to start the basic and way to go for next steps :)

